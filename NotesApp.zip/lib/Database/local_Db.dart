// import 'dart:io';

// import 'package:path/path.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:sqflite/sqflite.dart';

// class Dbhelper {
//   final String TABLES_NOES = 'notes';
//   final String COLUMN_NOTES_SNO = 's_no';
//   final String COLUMN_NOTES_TITLE = 'Title';
//   final String COLUMN_NOTES_DEC = 'Description';

//   // singleton
//   Dbhelper._();

//   static final Dbhelper getInstance = Dbhelper._();

//   Database? myDb;
//   // db open (path -> if exist then open else create )
//   Future<Database> getDb() async {
//     if (myDb != null) {
//       return myDb!;
//     } else {
//       myDb = await openDb();
//       return myDb!;
//     }
//   }

//   Future<Database> openDb() async {
//     Directory notesappdir = await getApplicationDocumentsDirectory();

//     String dbpath = join(notesappdir.path, 'notesDb.db');

//     return await openDatabase(dbpath, onCreate: (db, version) {
//       // create tables here
//       db.execute(
//           'create tables $TABLES_NOES( $COLUMN_NOTES_SNO integer primary key autoincrement , $COLUMN_NOTES_TITLE Text , $COLUMN_NOTES_DEC Text)');
//     }, version: 01);
//   }

//   // all queries here
//   // insertion
//   Future<bool> addnotes(
//       {required String Ntitle, required String NDescrip}) async {
//     var db = await getDb();
//     int rowseffected = await db.insert(TABLES_NOES, {
//       COLUMN_NOTES_DEC: NDescrip,
//       COLUMN_NOTES_TITLE: Ntitle,
//     });

//     return rowseffected > 0;
//   }

//   Future<List<Map<String, dynamic>>> getnotes() async {
//     var db = await getDb();
//     List<Map<String, dynamic>> mydata = await db.query(TABLES_NOES);
//     return mydata;
//   }
//   //
//   // insertion

//   //
// }
//
//
import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class Dbhelper {
  final String TABLE_NOTES = 'notes';
  final String COLUMN_NOTES_SNO = 's_no';
  final String COLUMN_NOTES_TITLE = 'title';
  final String COLUMN_NOTES_DESC = 'description';

  Dbhelper._();
  static final Dbhelper getInstance = Dbhelper._();

  Database? myDb;

  Future<Database> getDb() async {
    if (myDb != null) {
      return myDb!;
    } else {
      myDb = await openDb();
      return myDb!;
    }
  }

  Future<Database> openDb() async {
    Directory notesappdir = await getApplicationDocumentsDirectory();
    String dbpath = join(notesappdir.path, 'notesDb.db');

    return await openDatabase(
      dbpath,
      version: 1,
      onCreate: (db, version) {
        db.execute('''
          CREATE TABLE $TABLE_NOTES (
            $COLUMN_NOTES_SNO INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_NOTES_TITLE TEXT,
            $COLUMN_NOTES_DESC TEXT
          )
        ''');
      },
    );
  }

  Future<bool> addnotes(
      {required String Ntitle, required String NDescrip}) async {
    try {
      var db = await getDb();
      int rowseffected = await db.insert(TABLE_NOTES, {
        COLUMN_NOTES_TITLE: Ntitle,
        COLUMN_NOTES_DESC: NDescrip,
      });
      return rowseffected > 0;
    } catch (e) {
      print("Insert error: $e");
      return false;
    }
  }

  Future<List<Map<String, dynamic>>> getnotes() async {
    try {
      var db = await getDb();
      return await db.query(TABLE_NOTES);
    } catch (e) {
      print("Query error: $e");
      return [];
    }
  }

  Future<bool> updatenotes(
      {required String title,
      required String descrip,
      required int sno}) async {
    var db = await getDb();

    int roweffected = await db.update(
        TABLE_NOTES,
        {
          COLUMN_NOTES_TITLE: title,
          COLUMN_NOTES_DESC: descrip,
        },
        where: "$COLUMN_NOTES_SNO = $sno");
    return roweffected > 0;
  }

  Future<bool> deletenotes({required int sno}) async {
    var db = await getDb();

    int roweffected =
        await db.delete(TABLE_NOTES, where: "$COLUMN_NOTES_SNO = $sno");
    return roweffected > 0;
  }
}
