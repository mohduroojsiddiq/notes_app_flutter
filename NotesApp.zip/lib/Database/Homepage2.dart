import 'package:flutter/material.dart';
import 'package:notesapp/Database/local_Db.dart';

class homepage2 extends StatefulWidget {
  @override
  State<homepage2> createState() => _homepage2State();
}

class _homepage2State extends State<homepage2> {
  TextEditingController titlecontroller = TextEditingController();
  TextEditingController descripcontroller = TextEditingController();

  List<Map<String, dynamic>> allnotes = [];
  Dbhelper? dbRef;

  @override
  void initState() {
    super.initState();
    dbRef = Dbhelper.getInstance;
    getNotes();
  }

  void getNotes() async {
    allnotes = await dbRef!.getnotes();
    setState(() {});
  }

  void clearFields() {
    titlecontroller.clear();
    descripcontroller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notes App By Urooj",
            style: TextStyle(
                color: Colors.green,
                fontSize: 24,
                fontWeight: FontWeight.bold)),
      ),
      body: allnotes.isNotEmpty
          ? ListView.builder(
              itemCount: allnotes.length,
              itemBuilder: (_, index) {
                return ListTile(
                    leading: Text('${index + 1}'),
                    title: Text(allnotes[index]
                        [Dbhelper.getInstance.COLUMN_NOTES_TITLE]),
                    subtitle: Text(allnotes[index]
                        [Dbhelper.getInstance.COLUMN_NOTES_DESC]),
                    trailing: SizedBox(
                      width: 50,
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {},
                            child: Icon(Icons.edit),
                          ),
                          InkWell(
                            onTap: () async {
                              bool check = await dbRef!.deletenotes(
                                  sno: allnotes[index]
                                      [Dbhelper.getInstance.COLUMN_NOTES_SNO]);
                              if (check) {
                                getNotes();
                              }
                            },
                            child: Icon(Icons.delete),
                          )
                        ],
                      ),
                    ));
              })
          : Center(
              child: Text('You haven\'t created any notes'),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (context) {
                String errormsg = "";
                return StatefulBuilder(builder: (context, setModalState) {
                  return Padding(
                    padding: MediaQuery.of(context).viewInsets,
                    child: SingleChildScrollView(
                      child: Container(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "Add Notes",
                              style: TextStyle(
                                  fontSize: 26, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 19),
                            TextField(
                              controller: titlecontroller,
                              decoration: InputDecoration(
                                hintText: "Enter notes title here",
                                labelText: 'Title',
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(11),
                                ),
                              ),
                            ),
                            SizedBox(height: 11),
                            TextField(
                              controller: descripcontroller,
                              maxLines: 4,
                              decoration: InputDecoration(
                                hintText: "Enter notes description here",
                                labelText: "Description",
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(11),
                                ),
                              ),
                            ),
                            SizedBox(height: 11),
                            Row(
                              children: [
                                OutlinedButton(
                                  onPressed: () async {
                                    var mtitle = titlecontroller.text.trim();
                                    var mdescrip =
                                        descripcontroller.text.trim();

                                    if (mtitle.isNotEmpty &&
                                        mdescrip.isNotEmpty) {
                                      bool check = await dbRef!.addnotes(
                                          Ntitle: mtitle, NDescrip: mdescrip);

                                      if (check) {
                                        clearFields();
                                        getNotes();
                                        Navigator.pop(context);
                                      } else {
                                        setModalState(() {
                                          errormsg =
                                              "Failed to add note. Try again.";
                                        });
                                      }
                                    } else {
                                      setModalState(() {
                                        errormsg =
                                            "Please fill in all the fields.";
                                      });
                                    }
                                  },
                                  child: Text("Add Notes"),
                                ),
                                SizedBox(width: 7),
                                OutlinedButton(
                                  onPressed: () {
                                    clearFields();
                                    Navigator.pop(context);
                                  },
                                  child: Text("Cancel"),
                                ),
                              ],
                            ),
                            if (errormsg.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  errormsg,
                                  style: TextStyle(color: Colors.red),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                });
              });
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
