import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:notesapp/Database/local_Db.dart';
import 'package:path/path.dart';

class homepage extends StatefulWidget {
  @override
  State<homepage> createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  TextEditingController titlecontroller = TextEditingController();
  TextEditingController descripcontroller = TextEditingController();

  List<Map<String, dynamic>> allnotes = [];
  Dbhelper? dbRef;

  @override
  void initState() {
    super.initState();
    dbRef = Dbhelper.getInstance;
    getNotes();
  }

  void getNotes() async {
    allnotes = await dbRef!.getnotes();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Notes App By Urooj",
            style: TextStyle(
                color: Colors.green,
                fontSize: 24,
                fontWeight: FontWeight.bold)),
      ),
      body: allnotes.isNotEmpty
          ? ListView.builder(
              itemCount: allnotes.length,
              itemBuilder: (_, index) {
                return ListTile(
                  leading: Text(' ${allnotes[index][dbRef?.COLUMN_NOTES_SNO]}'),
                  title: Text(
                      allnotes[index][Dbhelper.getInstance.COLUMN_NOTES_TITLE]),
                  subtitle: Text(
                      allnotes[index][Dbhelper.getInstance.COLUMN_NOTES_DESC]),
                );
              })
          : Center(
              child: Text('You Havent create any notes'),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          String errormsg = "";
          showModalBottomSheet(
              context: context,
              builder: (Context) {
                return Container(
                  width: double.infinity,
                  child: Column(
                    children: [
                      Text(
                        "Add Notes",
                        style: TextStyle(
                            fontSize: 26, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 19,
                      ),
                      TextField(
                        controller: titlecontroller,
                        decoration: InputDecoration(
                          hintText: "Enter notes title here",
                          label: Text('Title'),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.red),
                            borderRadius: BorderRadius.circular(11),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(11),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 11,
                      ),
                      TextField(
                        controller: descripcontroller,
                        maxLines: 4,
                        decoration: InputDecoration(
                            hintText: "Enter notes Descrip.. here",
                            label: Text("Description"),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(11),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(11))),
                      ),
                      SizedBox(
                        height: 11,
                      ),
                      Row(
                        children: [
                          OutlinedButton(
                              onPressed: () async {
                                var mtitle = titlecontroller.text;
                                var mdescrip = descripcontroller.text;
                                if (mtitle.isNotEmpty && mdescrip.isNotEmpty) {
                                  bool check = await dbRef!.addnotes(
                                      Ntitle: mtitle, NDescrip: mdescrip);

                                  if (check) {
                                    getNotes();
                                  }

                                  Navigator.pop(context);
                                } else {
                                  setState(() {
                                    errormsg = 'Please add all the data field';
                                  });
                                }
                                titlecontroller.clear();
                                descripcontroller.clear();
                              },
                              child: Text("Add Notes")),
                          SizedBox(
                            width: 7,
                          ),
                          OutlinedButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text("Cancel")),
                        ],
                      ),
                      Text('$errormsg')
                    ],
                  ),
                );
              });
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
