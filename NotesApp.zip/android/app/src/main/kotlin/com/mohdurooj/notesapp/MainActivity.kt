package com.mohdurooj.notesapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
